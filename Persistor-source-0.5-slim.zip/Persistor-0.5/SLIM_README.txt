Persistor 0.5.0-wip — slim source package for GitHub web upload (<25 MB)

What was removed (already present in your 0.4 repo / CI artifacts):
- app/src/main/cpp/jpegli/  (vendored jpegli + third_party, ~28 MB)
- project.zip, Persistor-changes.zip

How to restore a full build tree:
1. Keep your existing jpegli tree from 0.4, OR
2. Re-extract only that path from the full archive:
   unzip Persistor-source-0.5-full.zip "Persistor-0.5/app/src/main/cpp/jpegli/*"

All application Kotlin sources for points 1–3, 5, 6 are included and overwrite 0.4 files.
