package com.persistor

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.OrientationEventListener
import android.view.TextureView
import android.view.WindowManager
import android.graphics.SurfaceTexture
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

/**
 * Камера Persistor. Экран зафиксирован в портрете, а поворот телефона определяется датчиком
 * (OrientationEventListener), поэтому работает при выключенном автоповороте экрана.
 */
class CameraActivity : ComponentActivity() {
    private val angle = mutableIntStateOf(0)
    private var listener: OrientationEventListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        listener = object : OrientationEventListener(this) {
            override fun onOrientationChanged(orientation: Int) {
                if (orientation == ORIENTATION_UNKNOWN) return
                angle.intValue = ((orientation + 45) / 90 * 90) % 360
            }
        }
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { CameraScreen(angle) } }
    }

    override fun onResume() {
        super.onResume()
        listener?.enable()
    }

    override fun onPause() {
        listener?.disable()
        super.onPause()
    }
}

@Composable
fun CameraScreen(angleState: MutableIntState) {
    val ctx = LocalContext.current
    val activity = ctx as ComponentActivity
    val appCtx = ctx.applicationContext

    val store = remember { FolderStore(appCtx) }
    val repo = remember { ImageRepository(appCtx) }
    val sources by store.sources.collectAsState(initial = emptySet())
    val targets = remember(sources) { sources.sortedBy { it.toString() } }
    var targetIdx by remember { mutableIntStateOf(0) }
    val target: Uri? = if (targets.isEmpty()) null else targets[targetIdx % targets.size]

    var hasPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasPermission = it }
    LaunchedEffect(Unit) { if (!hasPermission) permLauncher.launch(Manifest.permission.CAMERA) }

    var errorText by remember { mutableStateOf<String?>(null) }
    var savedCount by remember { mutableIntStateOf(0) }
    var lastSaved by remember { mutableStateOf<String?>(null) }
    var torch by remember { mutableStateOf(false) }
    var clean by remember { mutableStateOf(true) }
    var showDiag by remember { mutableStateOf(false) }
    var lensIdx by remember { mutableIntStateOf(0) }
    var lensMenu by remember { mutableStateOf(false) }

    val controller = remember {
        CameraController(
            appCtx,
            onError = { errorText = it },
            onSaved = { name -> savedCount++; lastSaved = name; errorText = null },
        )
    }
    SideEffect { controller.saveDir = target }
    DisposableEffect(Unit) { onDispose { controller.release() } }

    val lenses = remember { runCatching { controller.lenses() }.getOrDefault(emptyList()) }
    val lens = lenses.getOrNull(lensIdx)
    val planResult = remember(lens) { lens?.let { runCatching { controller.plan(it) } } }
    val plan = planResult?.getOrNull()
    val planError = planResult?.exceptionOrNull()?.message

    LaunchedEffect(torch) { controller.setTorch(torch) }
    LaunchedEffect(clean) { controller.setClean(clean) }

    // Превью и жизненный цикл камеры
    val tvRef = remember { mutableStateOf<TextureView?>(null) }
    val openCamera = rememberUpdatedState<() -> Unit>({
        val tv = tvRef.value
        val st = tv?.surfaceTexture
        if (hasPermission && lens != null && plan != null && tv != null && tv.isAvailable && st != null) {
            controller.open(lens, plan, st)
        }
    })
    LaunchedEffect(plan, hasPermission) {
        controller.close()
        openCamera.value()
    }
    DisposableEffect(Unit) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_PAUSE) controller.close()
            if (e == Lifecycle.Event.ON_RESUME) openCamera.value()
        }
        activity.lifecycle.addObserver(obs)
        onDispose { activity.lifecycle.removeObserver(obs) }
    }

    // Плавный поворот элементов интерфейса (кратчайшим путём)
    var cont by remember { mutableFloatStateOf(0f) }
    val a = angleState.intValue
    LaunchedEffect(a) {
        val norm = ((cont % 360f) + 360f) % 360f
        var d = a - norm
        if (d > 180f) d -= 360f
        if (d <= -180f) d += 360f
        cont += d
    }
    val uiRot by animateFloatAsState(cont, label = "uiRot")

    BackHandler(enabled = showDiag) { showDiag = false }

    if (showDiag) {
        DiagScreen(onBack = { showDiag = false })
        return
    }

    val ready = target != null && plan != null && hasPermission && !controller.busy

    Column(Modifier.fillMaxSize().background(Color.Black).systemBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { activity.finish() }) {
                Text("✕ Закрыть", color = Color.White, modifier = Modifier.rotate(uiRot))
            }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { showDiag = true }) {
                Text("Диагностика", color = Color.White, modifier = Modifier.rotate(uiRot))
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) {
                TextButton(onClick = { lensMenu = true }) {
                    Text(lens?.label ?: "нет камер", color = Color.White, maxLines = 1, modifier = Modifier.rotate(uiRot))
                }
                DropdownMenu(expanded = lensMenu, onDismissRequest = { lensMenu = false }) {
                    lenses.forEachIndexed { i, l ->
                        DropdownMenuItem(text = { Text(l.label) }, onClick = { lensIdx = i; lensMenu = false })
                    }
                }
            }
            if (plan?.flashAvailable == true) {
                TextButton(onClick = { torch = !torch }) {
                    Text(
                        if (torch) "Вспышка: вкл" else "Вспышка: выкл",
                        color = if (torch) Color(0xFFFFD54F) else Color.White,
                        modifier = Modifier.rotate(uiRot),
                    )
                }
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            when {
                !hasPermission -> Text("Нужно разрешение на камеру", color = Color.White)
                plan == null -> Text(planError ?: "Камеры не найдены", color = Color.White)
                else -> AndroidView(
                    factory = { c ->
                        TextureView(c).apply {
                            surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                                override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                                    openCamera.value()
                                }
                                override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
                                override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                                    controller.close()
                                    return true
                                }
                                override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
                            }
                            tvRef.value = this
                        }
                    },
                    modifier = Modifier.aspectRatio(plan.uprightAspect),
                )
            }
        }

        Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            if (plan != null) {
                val mp = plan.captureSize.width.toLong() * plan.captureSize.height / 1_000_000.0
                Text(
                    "Снимок: ${plan.captureSize.width}×${plan.captureSize.height} (${"%.1f".format(mp)} Мп)",
                    color = Color.LightGray, style = MaterialTheme.typography.bodySmall,
                )
            }
            Text(
                if (target != null) {
                    "Папка: ${repo.folderName(target)}" + if (targets.size > 1) " (нажмите, чтобы сменить)" else ""
                } else "Исходная папка не выбрана: выберите её в Persistor",
                color = Color.LightGray,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.clickable(enabled = targets.size > 1) { targetIdx++ }.padding(4.dp),
            )
            lastSaved?.let {
                Text("Сохранено: $it · всего: $savedCount", color = Color(0xFF9CCC65), style = MaterialTheme.typography.bodySmall)
            }
            errorText?.let { Text(it, color = Color(0xFFFF8A80), style = MaterialTheme.typography.bodySmall) }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = clean, onCheckedChange = { clean = it })
                    Spacer(Modifier.width(6.dp))
                    Text("Чистая", color = Color.White, modifier = Modifier.rotate(uiRot))
                }
                Box(
                    Modifier.size(78.dp).clip(CircleShape)
                        .background(if (ready) Color.White else Color.Gray)
                        .clickable(enabled = ready) { controller.takePicture(angleState.intValue) }
                )
                Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun DiagScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val report = remember { CameraDiagnostics.report(ctx) }
    Column(Modifier.fillMaxSize().background(Color.Black).systemBarsPadding().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← Назад") }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = {
                val cm = ctx.getSystemService(ClipboardManager::class.java)
                cm.setPrimaryClip(ClipData.newPlainText("camera report", report))
                Toast.makeText(ctx, "Скопировано", Toast.LENGTH_SHORT).show()
            }) { Text("Копировать") }
        }
        Text("Диагностика камер", style = MaterialTheme.typography.titleMedium, color = Color.White)
        Spacer(Modifier.height(8.dp))
        Text(
            report,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = Color.White,
            modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()),
        )
    }
}
