package com.persistor

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.pm.PackageManager
import android.graphics.Matrix
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.OrientationEventListener
import android.view.Surface
import android.view.TextureView
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

/**
 * Камера Persistor. Экран вращается вместе с телефоном по датчику положения,
 * независимо от системной настройки автоповорота (screenOrientation = fullSensor).
 * Угол по датчику используется ещё и для ориентации самого снимка.
 */
class CameraActivity : ComponentActivity() {
    private val angle = mutableIntStateOf(0)
    private var listener: OrientationEventListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        listener = object : OrientationEventListener(this) {
            override fun onOrientationChanged(orientation: Int) {
                if (orientation == ORIENTATION_UNKNOWN) return
                angle.intValue = ((orientation + 45) / 90 * 90) % 360
            }
        }
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { CameraScreen(angle) } }
    }

    override fun onResume() {
        super.onResume()
        listener?.enable()
    }

    override fun onPause() {
        listener?.disable()
        super.onPause()
    }
}

private fun displayRotation(activity: ComponentActivity): Int =
    if (Build.VERSION.SDK_INT >= 30) activity.display?.rotation ?: Surface.ROTATION_0
    else legacyRotation(activity)

@Suppress("DEPRECATION")
private fun legacyRotation(activity: ComponentActivity): Int =
    activity.windowManager.defaultDisplay.rotation

/**
 * Поворот и масштаб превью под текущее положение экрана (схема из примера Camera2Basic).
 * В портрете поправок не нужно, в альбомном положении изображение поворачивается матрицей.
 */
private fun applyPreviewTransform(tv: TextureView, plan: CameraPlan, rotation: Int) {
    val vw = tv.width.toFloat()
    val vh = tv.height.toFloat()
    if (vw == 0f || vh == 0f) return
    val m = Matrix()
    val viewRect = RectF(0f, 0f, vw, vh)
    val cx = viewRect.centerX()
    val cy = viewRect.centerY()
    when (rotation) {
        Surface.ROTATION_90, Surface.ROTATION_270 -> {
            val pw = plan.previewSize.width.toFloat()
            val ph = plan.previewSize.height.toFloat()
            val bufferRect = RectF(0f, 0f, ph, pw)
            bufferRect.offset(cx - bufferRect.centerX(), cy - bufferRect.centerY())
            m.setRectToRect(viewRect, bufferRect, Matrix.ScaleToFit.FILL)
            val scale = maxOf(vh / ph, vw / pw)
            m.postScale(scale, scale, cx, cy)
            m.postRotate(90f * (rotation - 2), cx, cy)
        }
        Surface.ROTATION_180 -> m.postRotate(180f, cx, cy)
    }
    tv.setTransform(m)
}

@Composable
fun CameraScreen(angleState: MutableIntState) {
    val ctx = LocalContext.current
    val activity = ctx as ComponentActivity
    val appCtx = ctx.applicationContext

    val config = LocalConfiguration.current
    val landscape = config.screenWidthDp > config.screenHeightDp
    val rotation = displayRotation(activity)

    val store = remember { FolderStore(appCtx) }
    val repo = remember { ImageRepository(appCtx) }
    val sources by store.sources.collectAsState(initial = emptySet())
    val targets = remember(sources) { sources.sortedBy { it.toString() } }
    var targetIdx by remember { mutableIntStateOf(0) }
    val target: Uri? = if (targets.isEmpty()) null else targets[targetIdx % targets.size]

    var hasPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasPermission = it }
    LaunchedEffect(Unit) { if (!hasPermission) permLauncher.launch(Manifest.permission.CAMERA) }

    var errorText by remember { mutableStateOf<String?>(null) }
    var savedCount by remember { mutableIntStateOf(0) }
    var lastSaved by remember { mutableStateOf<String?>(null) }
    var torch by remember { mutableStateOf(false) }
    var clean by remember { mutableStateOf(true) }
    var showDiag by remember { mutableStateOf(false) }
    var lensIdx by remember { mutableIntStateOf(0) }
    var lensMenu by remember { mutableStateOf(false) }

    val controller = remember {
        CameraController(
            appCtx,
            onError = { errorText = it },
            onSaved = { name -> savedCount++; lastSaved = name; errorText = null },
        )
    }
    SideEffect { controller.saveDir = target }
    DisposableEffect(Unit) { onDispose { controller.release() } }

    val lenses = remember { runCatching { controller.lenses() }.getOrDefault(emptyList()) }
    val lens = lenses.getOrNull(lensIdx)
    val planResult = remember(lens) { lens?.let { runCatching { controller.plan(it) } } }
    val plan = planResult?.getOrNull()
    val planError = planResult?.exceptionOrNull()?.message

    LaunchedEffect(torch) { controller.setTorch(torch) }
    LaunchedEffect(clean) { controller.setClean(clean) }

    // Превью и жизненный цикл камеры
    val tvRef = remember { mutableStateOf<TextureView?>(null) }
    val planHolder = rememberUpdatedState(plan)
    val rotationHolder = rememberUpdatedState(rotation)
    val openCamera = rememberUpdatedState<() -> Unit>({
        val tv = tvRef.value
        val st = tv?.surfaceTexture
        if (hasPermission && lens != null && plan != null && tv != null && tv.isAvailable && st != null) {
            controller.open(lens, plan, st)
        }
    })
    LaunchedEffect(plan, hasPermission) {
        controller.close()
        openCamera.value()
    }
    DisposableEffect(Unit) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_PAUSE) controller.close()
            if (e == Lifecycle.Event.ON_RESUME) openCamera.value()
        }
        activity.lifecycle.addObserver(obs)
        onDispose { activity.lifecycle.removeObserver(obs) }
    }

    BackHandler(enabled = showDiag) { showDiag = false }

    if (showDiag) {
        DiagScreen(onBack = { showDiag = false })
        return
    }

    val ready = target != null && plan != null && hasPermission && !controller.busy

    // ---- Общие элементы управления ----
    val closeBtn: @Composable () -> Unit = {
        TextButton(onClick = { activity.finish() }) { Text("✕ Закрыть", color = Color.White) }
    }
    val diagBtn: @Composable () -> Unit = {
        TextButton(onClick = { showDiag = true }) { Text("Диагностика", color = Color.White) }
    }
    val lensSel: @Composable () -> Unit = {
        Box {
            TextButton(onClick = { lensMenu = true }) {
                Text(lens?.label ?: "нет камер", color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            DropdownMenu(expanded = lensMenu, onDismissRequest = { lensMenu = false }) {
                lenses.forEachIndexed { i, l ->
                    DropdownMenuItem(text = { Text(l.label) }, onClick = { lensIdx = i; lensMenu = false })
                }
            }
        }
    }
    val flashBtn: @Composable () -> Unit = {
        if (plan?.flashAvailable == true) {
            TextButton(onClick = { torch = !torch }) {
                Text(
                    if (torch) "Вспышка: вкл" else "Вспышка: выкл",
                    color = if (torch) Color(0xFFFFD54F) else Color.White,
                )
            }
        }
    }
    val cleanSw: @Composable () -> Unit = {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = clean, onCheckedChange = { clean = it })
            Spacer(Modifier.width(6.dp))
            Text("Чистая", color = Color.White)
        }
    }
    val infoTexts: @Composable () -> Unit = {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            if (plan != null) {
                val mp = plan.captureSize.width.toLong() * plan.captureSize.height / 1_000_000.0
                Text(
                    "Снимок: ${plan.captureSize.width}×${plan.captureSize.height} (${"%.1f".format(mp)} Мп)",
                    color = Color.LightGray, style = MaterialTheme.typography.bodySmall,
                )
            }
            Text(
                if (target != null) {
                    "Папка: ${repo.folderName(target)}" + if (targets.size > 1) " (нажмите, чтобы сменить)" else ""
                } else "Исходная папка не выбрана: выберите её в Persistor",
                color = Color.LightGray,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.clickable(enabled = targets.size > 1) { targetIdx++ }.padding(4.dp),
            )
            lastSaved?.let {
                Text("Сохранено: $it · всего: $savedCount", color = Color(0xFF9CCC65), style = MaterialTheme.typography.bodySmall)
            }
            errorText?.let { Text(it, color = Color(0xFFFF8A80), style = MaterialTheme.typography.bodySmall) }
        }
    }
    val shutter: @Composable () -> Unit = {
        Box(
            Modifier.size(78.dp).clip(CircleShape)
                .background(if (ready) Color.White else Color.Gray)
                .clickable(enabled = ready) { controller.takePicture(angleState.intValue) }
        )
    }

    // ---- Превью: всегда в одном месте дерева, поэтому при повороте не пересоздаётся ----
    val preview: @Composable () -> Unit = {
        when {
            !hasPermission -> Text("Нужно разрешение на камеру", color = Color.White)
            plan == null -> Text(planError ?: "Камеры не найдены", color = Color.White)
            else -> {
                val aspect = if (landscape) 1f / plan.uprightAspect else plan.uprightAspect
                AndroidView(
                    factory = { c ->
                        TextureView(c).apply {
                            surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                                override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                                    planHolder.value?.let { applyPreviewTransform(this@apply, it, rotationHolder.value) }
                                    openCamera.value()
                                }

                                override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {
                                    planHolder.value?.let { applyPreviewTransform(this@apply, it, rotationHolder.value) }
                                }

                                override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                                    controller.closeIfTexture(st)
                                    return true
                                }

                                override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
                            }
                            addOnLayoutChangeListener { v, _, _, _, _, _, _, _, _ ->
                                planHolder.value?.let { applyPreviewTransform(v as TextureView, it, rotationHolder.value) }
                            }
                            tvRef.value = this
                        }
                    },
                    update = { tv -> applyPreviewTransform(tv, plan, rotation) },
                    modifier = Modifier.aspectRatio(aspect),
                )
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black).systemBarsPadding()) {
        Box(
            Modifier.fillMaxSize(),
            contentAlignment = if (landscape) Alignment.CenterStart else Alignment.Center,
        ) { preview() }

        if (landscape) {
            // Альбомное положение: панель управления справа
            Column(
                Modifier.align(Alignment.CenterEnd).width(210.dp).fillMaxHeight()
                    .background(Color.Black.copy(alpha = 0.6f))
                    .verticalScroll(rememberScrollState()).padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                closeBtn()
                diagBtn()
                lensSel()
                flashBtn()
                cleanSw()
                Spacer(Modifier.height(8.dp))
                infoTexts()
                Spacer(Modifier.height(8.dp))
                shutter()
            }
        } else {
            Column(Modifier.align(Alignment.TopCenter).fillMaxWidth().background(Color.Black.copy(alpha = 0.5f))) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    closeBtn()
                    Spacer(Modifier.weight(1f))
                    diagBtn()
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f)) { lensSel() }
                    flashBtn()
                }
            }
            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.5f)).padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                infoTexts()
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f)) { cleanSw() }
                    shutter()
                    Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun DiagScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val report = remember { CameraDiagnostics.report(ctx) }
    Column(Modifier.fillMaxSize().background(Color.Black).systemBarsPadding().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← Назад") }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = {
                val cm = ctx.getSystemService(ClipboardManager::class.java)
                cm.setPrimaryClip(ClipData.newPlainText("camera report", report))
                Toast.makeText(ctx, "Скопировано", Toast.LENGTH_SHORT).show()
            }) { Text("Копировать") }
        }
        Text("Диагностика камер", style = MaterialTheme.typography.titleMedium, color = Color.White)
        Spacer(Modifier.height(8.dp))
        Text(
            report,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = Color.White,
            modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()),
        )
    }
}
