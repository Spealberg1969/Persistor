package com.persistor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface { MainScreen() } } }
    }
}

@Composable
fun MainScreen(vm: MainViewModel = viewModel()) {
    val s by vm.state.collectAsState()
    val running = s.progress.running

    // Экран не гаснет, пока идёт обработка
    val view = LocalView.current
    DisposableEffect(running) {
        view.keepScreenOn = running
        onDispose { view.keepScreenOn = false }
    }

    val pickSource = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { it?.let(vm::addSource) }
    val pickOutput = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { it?.let(vm::setOutput) }
    val pickArchive = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { it?.let(vm::setArchive) }

    var expanded by remember { mutableStateOf(true) }
    var confirmDelete by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().systemBarsPadding().padding(12.dp)) {

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Persistor", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
            TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "Настройки ▴" else "Настройки ▾") }
        }

        if (expanded) {
            Column(Modifier.heightIn(max = 340.dp).verticalScroll(rememberScrollState())) {
                Text("Исходные папки", style = MaterialTheme.typography.titleSmall)
                s.sources.forEach { uri ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(vm.repo.folderName(uri), Modifier.weight(1f))
                        TextButton(onClick = { vm.removeSource(uri) }) { Text("Убрать") }
                    }
                }
                OutlinedButton(onClick = { pickSource.launch(null) }) { Text("+ Добавить папку") }

                Spacer(Modifier.height(8.dp))
                FolderRow("Сжатые файлы (папка с датой создаётся внутри)", s.output?.let(vm.repo::folderName)) { pickOutput.launch(null) }
                FolderRow("Папка для ZIP", s.archive?.let(vm.repo::folderName)) { pickArchive.launch(null) }

                Spacer(Modifier.height(8.dp))
                var sl by remember(s.settings.ssimTarget) { mutableFloatStateOf(s.settings.ssimTarget.toFloat()) }
                Text("Целевое качество SSIM: ${"%.2f".format(sl)}", style = MaterialTheme.typography.titleSmall)
                Slider(
                    value = sl,
                    onValueChange = { sl = it },
                    onValueChangeFinished = { vm.setSsim((sl * 100).roundToInt() / 100.0) },
                    valueRange = 0.90f..0.99f,
                    steps = 8,
                )
                SwitchRow("Удалять папку со сжатыми файлами после архивации", s.settings.deleteTempFolder, vm::setDeleteTemp)
                SwitchRow("Удалять исходные фото после успешной архивации", s.settings.deleteOriginals, vm::setDeleteOriginals)
            }
        }

        Spacer(Modifier.height(8.dp))
        Text("Изображений: ${s.images.size}, выбрано: ${s.selected.size}")

        LazyVerticalGrid(
            columns = GridCells.Adaptive(110.dp),
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            items(s.images, key = { it.uri.toString() }) { img ->
                Box(Modifier.aspectRatio(1f).clickable { vm.toggle(img.uri) }) {
                    AsyncImage(
                        model = img.uri,
                        contentDescription = img.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                    Checkbox(
                        checked = img.uri in s.selected,
                        onCheckedChange = { vm.toggle(img.uri) },
                        modifier = Modifier.align(Alignment.TopEnd),
                    )
                }
            }
        }

        if (running) {
            Spacer(Modifier.height(8.dp))
            Text(s.progress.message, style = MaterialTheme.typography.bodySmall)
            LinearProgressIndicator(
                progress = { if (s.progress.total == 0) 0f else s.progress.current.toFloat() / s.progress.total },
                modifier = Modifier.fillMaxWidth(),
            )
        }

        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val allSelected = s.images.isNotEmpty() && s.selected.size == s.images.size
            OutlinedButton(onClick = { if (allSelected) vm.clearSelection() else vm.selectAll() }, enabled = !running) {
                Text(if (allSelected) "Снять всё" else "Выбрать все")
            }
            Button(
                onClick = { if (s.settings.deleteOriginals) confirmDelete = true else vm.process() },
                enabled = !running && s.selected.isNotEmpty() && s.output != null && s.archive != null,
                modifier = Modifier.weight(1f),
            ) { Text("Обработать (${s.selected.size})") }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Удалить исходные фото?") },
            text = { Text("После создания и проверки архива исходные фото будут удалены безвозвратно.") },
            confirmButton = { TextButton(onClick = { confirmDelete = false; vm.process() }) { Text("Продолжить") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Отмена") } },
        )
    }

    s.result?.let { r ->
        AlertDialog(
            onDismissRequest = vm::dismissResult,
            title = { Text(if (r is ProcessResult.Success) "Готово" else "Ошибка") },
            text = { Text(resultText(r)) },
            confirmButton = { TextButton(onClick = vm::dismissResult) { Text("OK") } },
        )
    }
}

private fun mb(bytes: Long) = "%.1f МБ".format(bytes / 1048576.0)

private fun resultText(r: ProcessResult): String = when (r) {
    is ProcessResult.Success -> buildString {
        appendLine("Архив: ${r.zipName}")
        appendLine("Файлов: ${r.files}")
        appendLine("Было: ${mb(r.originalBytes)} → архив: ${mb(r.zipSize)}")
        if (r.deletedOriginals > 0) appendLine("Удалено исходных фото: ${r.deletedOriginals}")
        if (r.zipSize > 17L * 1048576) appendLine("\n⚠ Архив больше 17 МБ, Gmail может его не принять.")
        r.warnings.forEach { appendLine("• $it") }
    }.trim()
    is ProcessResult.Failure -> r.reason
}

@Composable
private fun FolderRow(label: String, name: String?, onPick: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.titleSmall)
            Text(name ?: "не выбрана", style = MaterialTheme.typography.bodySmall)
        }
        OutlinedButton(onClick = onPick) { Text("Выбрать") }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
