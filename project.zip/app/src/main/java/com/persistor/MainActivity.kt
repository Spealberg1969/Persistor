package com.persistor

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface { MainScreen() } } }
    }
}

@Composable
fun MainScreen(vm: MainViewModel = viewModel()) {
    val s by vm.state.collectAsState()

    val pickSource = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { it?.let(vm::addSource) }
    val pickOutput = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { it?.let(vm::setOutput) }
    val pickArchive = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { it?.let(vm::setArchive) }

    Column(Modifier.fillMaxSize().systemBarsPadding().padding(12.dp)) {

        // --- Папки ---
        Text("Исходные папки", style = MaterialTheme.typography.titleSmall)
        s.sources.forEach { uri ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(vm.repo.folderName(uri), Modifier.weight(1f))
                TextButton(onClick = { vm.removeSource(uri) }) { Text("Убрать") }
            }
        }
        OutlinedButton(onClick = { pickSource.launch(null) }) { Text("+ Добавить папку") }

        Spacer(Modifier.height(8.dp))
        FolderRow("Сжатые файлы", s.output?.let(vm.repo::folderName)) { pickOutput.launch(null) }
        FolderRow("Папка для ZIP", s.archive?.let(vm.repo::folderName)) { pickArchive.launch(null) }

        Spacer(Modifier.height(8.dp))
        Text("Изображений: ${s.images.size}, выбрано: ${s.selected.size}")

        // --- Сетка ---
        LazyVerticalGrid(
            columns = GridCells.Adaptive(110.dp),
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            items(s.images, key = { it.uri.toString() }) { img ->
                Box(Modifier.aspectRatio(1f).clickable { vm.toggle(img.uri) }) {
                    AsyncImage(
                        model = img.uri,
                        contentDescription = img.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                    Checkbox(
                        checked = img.uri in s.selected,
                        onCheckedChange = { vm.toggle(img.uri) },
                        modifier = Modifier.align(Alignment.TopEnd),
                    )
                }
            }
        }

        // --- Нижняя панель ---
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val allSelected = s.images.isNotEmpty() && s.selected.size == s.images.size
            OutlinedButton(onClick = { if (allSelected) vm.clearSelection() else vm.selectAll() }) {
                Text(if (allSelected) "Снять всё" else "Выбрать все")
            }
            Button(
                onClick = { /* шаг 2: конвейер обработки */ },
                enabled = s.selected.isNotEmpty() && s.output != null && s.archive != null,
                modifier = Modifier.weight(1f),
            ) { Text("Обработать (${s.selected.size})") }
        }
    }
}

@Composable
private fun FolderRow(label: String, name: String?, onPick: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.titleSmall)
            Text(name ?: "не выбрана", style = MaterialTheme.typography.bodySmall)
        }
        OutlinedButton(onClick = onPick) { Text("Выбрать") }
    }
}
