package com.persistor

import android.content.Context
import android.net.Uri
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("settings")

/** Хранит выбранные папки (SAF tree URI) и настройки обработки между запусками. */
class FolderStore(private val context: Context) {
    private val SOURCES = stringSetPreferencesKey("sources")
    private val OUTPUT = stringPreferencesKey("output")
    private val ARCHIVE = stringPreferencesKey("archive")
    private val SSIM = doublePreferencesKey("ssim")
    private val DEL_TEMP = booleanPreferencesKey("del_temp")
    private val DEL_ORIG = booleanPreferencesKey("del_orig")

    val sources: Flow<Set<Uri>> = context.dataStore.data
        .map { p -> p[SOURCES].orEmpty().map(Uri::parse).toSet() }
    val output: Flow<Uri?> = context.dataStore.data.map { p -> p[OUTPUT]?.let(Uri::parse) }
    val archive: Flow<Uri?> = context.dataStore.data.map { p -> p[ARCHIVE]?.let(Uri::parse) }

    val settings: Flow<ProcessSettings> = context.dataStore.data.map { p ->
        ProcessSettings(
            ssimTarget = p[SSIM] ?: 0.95,
            deleteTempFolder = p[DEL_TEMP] ?: true,
            deleteOriginals = p[DEL_ORIG] ?: false,
        )
    }

    suspend fun addSource(uri: Uri) = context.dataStore.edit {
        it[SOURCES] = it[SOURCES].orEmpty() + uri.toString()
    }

    suspend fun removeSource(uri: Uri) = context.dataStore.edit {
        it[SOURCES] = it[SOURCES].orEmpty() - uri.toString()
    }

    suspend fun setOutput(uri: Uri) = context.dataStore.edit { it[OUTPUT] = uri.toString() }
    suspend fun setArchive(uri: Uri) = context.dataStore.edit { it[ARCHIVE] = uri.toString() }
    suspend fun setSsim(v: Double) = context.dataStore.edit { it[SSIM] = v }
    suspend fun setDeleteTemp(v: Boolean) = context.dataStore.edit { it[DEL_TEMP] = v }
    suspend fun setDeleteOriginals(v: Boolean) = context.dataStore.edit { it[DEL_ORIG] = v }
}
