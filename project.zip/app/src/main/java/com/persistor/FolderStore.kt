package com.persistor

import android.content.Context
import android.net.Uri
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("settings")

/** Хранит выбранные папки (как SAF tree URI) между запусками. */
class FolderStore(private val context: Context) {
    private val SOURCES = stringSetPreferencesKey("sources")
    private val OUTPUT = stringPreferencesKey("output")
    private val ARCHIVE = stringPreferencesKey("archive")

    val sources: Flow<Set<Uri>> = context.dataStore.data
        .map { p -> p[SOURCES].orEmpty().map(Uri::parse).toSet() }
    val output: Flow<Uri?> = context.dataStore.data.map { p -> p[OUTPUT]?.let(Uri::parse) }
    val archive: Flow<Uri?> = context.dataStore.data.map { p -> p[ARCHIVE]?.let(Uri::parse) }

    suspend fun addSource(uri: Uri) = context.dataStore.edit {
        it[SOURCES] = it[SOURCES].orEmpty() + uri.toString()
    }

    suspend fun removeSource(uri: Uri) = context.dataStore.edit {
        it[SOURCES] = it[SOURCES].orEmpty() - uri.toString()
    }

    suspend fun setOutput(uri: Uri) = context.dataStore.edit { it[OUTPUT] = uri.toString() }
    suspend fun setArchive(uri: Uri) = context.dataStore.edit { it[ARCHIVE] = uri.toString() }
}
