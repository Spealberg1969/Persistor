package com.persistor

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class UiState(
    val sources: Set<Uri> = emptySet(),
    val output: Uri? = null,
    val archive: Uri? = null,
    val images: List<ImageItem> = emptyList(),
    val selected: Set<Uri> = emptySet(),
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val store = FolderStore(app)
    val repo = ImageRepository(app)

    private val images = MutableStateFlow<List<ImageItem>>(emptyList())
    private val selected = MutableStateFlow<Set<Uri>>(emptySet())

    val state: StateFlow<UiState> = combine(
        store.sources, store.output, store.archive, images, selected
    ) { s, o, a, i, sel -> UiState(s, o, a, i, sel) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, UiState())

    init {
        // При изменении списка папок — перечитываем изображения
        viewModelScope.launch {
            store.sources.collect { src ->
                val list = repo.list(src)
                images.value = list
                selected.value = selected.value intersect list.map { it.uri }.toSet()
            }
        }
    }

    private fun persist(uri: Uri) {
        getApplication<Application>().contentResolver.takePersistableUriPermission(
            uri,
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        )
    }

    fun addSource(uri: Uri) { persist(uri); viewModelScope.launch { store.addSource(uri) } }
    fun removeSource(uri: Uri) = viewModelScope.launch { store.removeSource(uri) }
    fun setOutput(uri: Uri) { persist(uri); viewModelScope.launch { store.setOutput(uri) } }
    fun setArchive(uri: Uri) { persist(uri); viewModelScope.launch { store.setArchive(uri) } }

    fun refresh() = viewModelScope.launch { images.value = repo.list(state.value.sources) }

    fun toggle(uri: Uri) {
        selected.value = if (uri in selected.value) selected.value - uri else selected.value + uri
    }

    fun selectAll() { selected.value = images.value.map { it.uri }.toSet() }
    fun clearSelection() { selected.value = emptySet() }
}
