package com.persistor

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class UiState(
    val sources: Set<Uri> = emptySet(),
    val output: Uri? = null,
    val archive: Uri? = null,
    val images: List<ImageItem> = emptyList(),
    val selected: Set<Uri> = emptySet(),
    val settings: ProcessSettings = ProcessSettings(),
    val progress: ProcessProgress = ProcessProgress(),
    val result: ProcessResult? = null,
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val store = FolderStore(app)
    private val processor = Processor(app)
    val repo = ImageRepository(app)

    private val images = MutableStateFlow<List<ImageItem>>(emptyList())
    private val selected = MutableStateFlow<Set<Uri>>(emptySet())
    private val progress = MutableStateFlow(ProcessProgress())
    private val result = MutableStateFlow<ProcessResult?>(null)

    private val folders = combine(store.sources, store.output, store.archive) { s, o, a -> Triple(s, o, a) }
    private val items = combine(images, selected) { i, s -> i to s }

    val state: StateFlow<UiState> = combine(folders, items, store.settings, progress, result) { f, im, st, p, r ->
        UiState(f.first, f.second, f.third, im.first, im.second, st, p, r)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, UiState())

    init {
        viewModelScope.launch {
            store.sources.collect { src ->
                val list = repo.list(src)
                images.value = list
                selected.value = selected.value intersect list.map { it.uri }.toSet()
            }
        }
    }

    private fun persist(uri: Uri) {
        getApplication<Application>().contentResolver.takePersistableUriPermission(
            uri,
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        )
    }

    fun addSource(uri: Uri) { persist(uri); viewModelScope.launch { store.addSource(uri) } }
    fun removeSource(uri: Uri) = viewModelScope.launch { store.removeSource(uri) }
    fun setOutput(uri: Uri) { persist(uri); viewModelScope.launch { store.setOutput(uri) } }
    fun setArchive(uri: Uri) { persist(uri); viewModelScope.launch { store.setArchive(uri) } }

    fun setSsim(v: Double) = viewModelScope.launch { store.setSsim(v) }
    fun setDeleteTemp(v: Boolean) = viewModelScope.launch { store.setDeleteTemp(v) }
    fun setDeleteOriginals(v: Boolean) = viewModelScope.launch { store.setDeleteOriginals(v) }

    fun refresh() = viewModelScope.launch { images.value = repo.list(state.value.sources) }

    fun toggle(uri: Uri) {
        selected.value = if (uri in selected.value) selected.value - uri else selected.value + uri
    }

    fun selectAll() { selected.value = images.value.map { it.uri }.toSet() }
    fun clearSelection() { selected.value = emptySet() }
    fun dismissResult() { result.value = null }

    fun process() {
        val s = state.value
        val out = s.output ?: return
        val arc = s.archive ?: return
        if (s.progress.running) return
        val chosen = s.images.filter { it.uri in s.selected }
        if (chosen.isEmpty()) return
        result.value = null
        viewModelScope.launch {
            progress.value = ProcessProgress(true, "Старт…", 0, chosen.size)
            val r = processor.run(chosen, out, arc, s.settings) { msg, cur, tot ->
                progress.value = ProcessProgress(true, msg, cur, tot)
            }
            progress.value = ProcessProgress()
            result.value = r
            refresh()
        }
    }
}
