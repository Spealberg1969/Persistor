package com.persistor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class ProcessSettings(
    val ssimTarget: Double = 0.95,
    val minQuality: Int = 40,              // нижняя граница Q: защита от нечитаемого текста
    val deleteTempFolder: Boolean = true,  // удалить папку со сжатыми файлами после архивации
    val deleteOriginals: Boolean = false,  // удалить исходные фото после успешной архивации
)

data class ProcessProgress(val running: Boolean = false, val message: String = "", val current: Int = 0, val total: Int = 0)

sealed interface ProcessResult {
    data class Success(
        val zipName: String,
        val zipUri: Uri,
        val zipSize: Long,
        val files: Int,
        val originalBytes: Long,
        val deletedOriginals: Int,
        val warnings: List<String>,
        val shareUri: Uri? = null,
        val createdAt: Long = System.currentTimeMillis(),
    ) : ProcessResult

    data class Failure(val reason: String) : ProcessResult
}

class Processor(private val context: Context) {
    private val resolver get() = context.contentResolver

    suspend fun run(
        images: List<ImageItem>,
        outputTree: Uri,
        archiveTree: Uri,
        settings: ProcessSettings,
        onProgress: (String, Int, Int) -> Unit,
    ): ProcessResult = withContext(Dispatchers.Default) {
        try {
            doRun(images, outputTree, archiveTree, settings, onProgress)
        } catch (e: CancellationException) {
            throw e
        } catch (e: OutOfMemoryError) {
            ProcessResult.Failure("Не хватило памяти на обработку большого снимка. Исходные фото не тронуты.")
        } catch (e: Exception) {
            ProcessResult.Failure("Ошибка: ${e.message ?: e.javaClass.simpleName}. Исходные фото не тронуты.")
        }
    }

    private suspend fun doRun(
        images: List<ImageItem>,
        outputTree: Uri,
        archiveTree: Uri,
        st: ProcessSettings,
        onProgress: (String, Int, Int) -> Unit,
    ): ProcessResult {
        if (images.isEmpty()) return ProcessResult.Failure("Не выбрано ни одного файла")

        val outRoot = DocumentFile.fromTreeUri(context, outputTree)
        val arcRoot = DocumentFile.fromTreeUri(context, archiveTree)
        if (outRoot == null || arcRoot == null || !outRoot.canWrite() || !arcRoot.canWrite()) {
            return ProcessResult.Failure("Нет доступа на запись в выбранные папки. Выберите их заново.")
        }

        // Имя папки/архива: текущая дата; при повторном запуске в тот же день — _2, _3...
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        var n = 1
        fun nameFor(i: Int) = if (i == 1) date else "${date}_$i"
        while (outRoot.findFile(nameFor(n)) != null || arcRoot.findFile("${nameFor(n)}.zip") != null) n++
        val folderName = nameFor(n)

        val folder = outRoot.createDirectory(folderName)
            ?: return ProcessResult.Failure("Не удалось создать папку $folderName")

        // 1. Сжатие
        val written = mutableListOf<Pair<String, Long>>()
        val warnings = mutableListOf<String>()
        var originalBytes = 0L
        for ((index, img) in images.withIndex()) {
            currentCoroutineContext().ensureActive()
            onProgress("Сжатие ${index + 1}/${images.size}: ${img.name}", index, images.size)

            var bytes = compressOne(img.uri, img.name, st, warnings)
            val isJpeg = img.name.lowercase().let { it.endsWith(".jpg") || it.endsWith(".jpeg") }
            if (isJpeg && bytes.size.toLong() >= img.size && img.size > 0) {
                // Пережатие не помогло — оставляем оригинальные байты
                bytes = resolver.openInputStream(img.uri)?.use { it.readBytes() } ?: bytes
                warnings += "${img.name}: уже оптимален, скопирован без изменений"
            }

            val fileName = uniqueName(folder, img.name.substringBeforeLast('.') + ".jpg")
            val doc = folder.createFile("image/jpeg", fileName)
                ?: return ProcessResult.Failure("Не удалось создать файл $fileName в папке $folderName")
            val out = resolver.openOutputStream(doc.uri)
                ?: return ProcessResult.Failure("Не удалось записать $fileName")
            out.use { it.write(bytes) }
            written += (doc.name ?: fileName) to bytes.size.toLong()
            originalBytes += img.size
        }

        // 2. ZIP
        onProgress("Создание архива…", images.size, images.size)
        val zipName = "$folderName.zip"
        val zipDoc = arcRoot.createFile("application/zip", zipName)
            ?: return ProcessResult.Failure("Не удалось создать архив $zipName")
        val zipStream = resolver.openOutputStream(zipDoc.uri)
            ?: return ProcessResult.Failure("Не удалось записать архив $zipName")
        ZipOutputStream(BufferedOutputStream(zipStream)).use { zip ->
            zip.setLevel(Deflater.NO_COMPRESSION) // JPEG всё равно не сжимается
            val files = folder.listFiles().filter { it.isFile }.sortedBy { it.name }
            for (f in files) {
                currentCoroutineContext().ensureActive()
                zip.putNextEntry(ZipEntry("$folderName/${f.name}"))
                resolver.openInputStream(f.uri)?.use { it.copyTo(zip) }
                zip.closeEntry()
            }
        }

        // 3. Проверка архива через ZipFile: наличие, размер и CRC каждого файла.
        // Архив SAF-каталога временно копируется в cache, а содержимое читается потоково.
        onProgress("Проверка архива…", images.size, images.size)
        val activeContext = currentCoroutineContext()
        val verifyFile = File.createTempFile("persistor-verify-", ".zip", context.cacheDir)
        val verificationError = try {
            val zipIn = resolver.openInputStream(zipDoc.uri)
                ?: error("Не удалось открыть архив для проверки")
            zipIn.use { input ->
                verifyFile.outputStream().buffered().use { output ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        activeContext.ensureActive()
                        val count = input.read(buffer)
                        if (count < 0) break
                        if (count > 0) output.write(buffer, 0, count)
                    }
                }
            }

            val expected = written.associate { (name, size) -> "$folderName/$name" to size }
            ArchiveVerifier.verify(verifyFile, expected) { activeContext.ensureActive() }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            "ошибка чтения ZIP/CRC: ${e.message ?: e.javaClass.simpleName}"
        } finally {
            verifyFile.delete()
        }
        if (verificationError != null) {
            zipDoc.delete()
            return ProcessResult.Failure(
                "Проверка архива не прошла: $verificationError. Исходные фото не тронуты, " +
                    "сжатые файлы остались в папке $folderName."
            )
        }
        val zipSize = zipDoc.length()

        // 4. Очистка — только после успешной проверки
        if (st.deleteTempFolder) folder.delete()
        var deleted = 0
        if (st.deleteOriginals) {
            for (img in images) {
                val ok2 = DocumentFile.fromSingleUri(context, img.uri)?.delete() == true
                if (ok2) deleted++ else warnings += "Не удалось удалить ${img.name}"
            }
        }

        return ProcessResult.Success(zipName, zipDoc.uri, zipSize, written.size, originalBytes, deleted, warnings)
    }

    /** Подбор минимального качества Q, при котором SSIM >= цели (бинарный поиск). */
    private fun compressOne(uri: Uri, name: String, st: ProcessSettings, warnings: MutableList<String>): ByteArray {
        val decoded = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            ?: error("Не удалось прочитать $name")
        val bmp = decoded.applyOrientation(readOrientation(uri))
        try {
            var lo = st.minQuality
            var hi = 95
            var best: ByteArray? = null
            var iter = 0
            while (lo <= hi && iter < 8) {
                iter++
                val mid = (lo + hi) / 2
                val bytes = encode(bmp, mid)
                if (ssimOf(bmp, bytes) >= st.ssimTarget) {
                    best = bytes
                    hi = mid - 1   // качество достаточное — пробуем сжать сильнее
                } else {
                    lo = mid + 1
                }
            }
            if (best == null) {
                warnings += "$name: цель SSIM не достигнута, использовано качество 95"
                best = encode(bmp, 95)
            }
            return best
        } finally {
            bmp.recycle()
        }
    }

    private fun encode(bmp: Bitmap, q: Int): ByteArray {
        val out = ByteArrayOutputStream(512 * 1024)
        bmp.compress(Bitmap.CompressFormat.JPEG, q, out)
        return out.toByteArray()
    }

    private fun ssimOf(orig: Bitmap, bytes: ByteArray): Double {
        val dec = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return 0.0
        try {
            return Ssim.compute(orig, dec)
        } finally {
            dec.recycle()
        }
    }

    private fun readOrientation(uri: Uri): Int =
        resolver.openInputStream(uri)?.use {
            ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        } ?: ExifInterface.ORIENTATION_NORMAL

    /** Физически поворачиваем пиксели по EXIF, потому что в результат EXIF не копируется. */
    private fun Bitmap.applyOrientation(o: Int): Bitmap {
        val m = Matrix()
        when (o) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(-90f); m.postScale(-1f, 1f) }
            else -> return this
        }
        val rotated = Bitmap.createBitmap(this, 0, 0, width, height, m, true)
        if (rotated !== this) recycle()
        return rotated
    }

    private fun uniqueName(dir: DocumentFile, name: String): String {
        if (dir.findFile(name) == null) return name
        val base = name.substringBeforeLast('.')
        val ext = name.substringAfterLast('.', "")
        var i = 2
        while (true) {
            val c = if (ext.isEmpty()) "${base}_$i" else "${base}_$i.$ext"
            if (dir.findFile(c) == null) return c
            i++
        }
    }
}
