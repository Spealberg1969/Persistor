package com.persistor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

enum class CompressionMethod(
    val key: String,
    val label: String,
    val extension: String,
    val mimeType: String,
) {
    ANDROID("android", "JPEG (Android)", "jpg", "image/jpeg"),
    JPEGLI("jpegli", "JPEGli (JPEG)", "jpg", "image/jpeg"),
    MOZJPEG("mozjpeg", "MozJPEG (JPEG)", "jpg", "image/jpeg"),
    WEBP("webp", "WebP lossy", "webp", "image/webp"),
    JPEG_XL("jpeg_xl", "JPEG XL", "jxl", "image/jxl"),
    HEIF("heif", "HEIF / HEIC", "heic", "image/heic"),
    AVIF("avif", "AVIF", "avif", "image/avif"),
    /** Single-page PDF with an embedded JPEG (DCTDecode). Quality is chosen via the same SSIM search as JPEG. */
    PDF_JPEG("pdf_jpeg", "PDF (JPEG)", "pdf", "application/pdf");

    val isPdf: Boolean get() = this == PDF_JPEG

    companion object {
        fun fromKey(key: String?): CompressionMethod = entries.firstOrNull { it.key == key } ?: ANDROID
    }
}

/** JPEG encoder used inside PDF pages (and optionally for camera PDF capture). */
enum class PdfInnerCodec(val key: String, val label: String) {
    ANDROID("android", "JPEG (Android)"),
    JPEGLI("jpegli", "JPEGli"),
    MOZJPEG("mozjpeg", "MozJPEG");

    companion object {
        fun fromKey(key: String?): PdfInnerCodec = entries.firstOrNull { it.key == key } ?: MOZJPEG
    }
}

/** Camera capture format: writes either .jpg or single-page .pdf into its own folder. */
enum class CaptureFormat(val key: String, val label: String) {
    JPEG("jpeg", "JPEG"),
    PDF("pdf", "PDF");

    companion object {
        fun fromKey(key: String?): CaptureFormat = entries.firstOrNull { it.key == key } ?: JPEG
    }
}

data class ProcessSettings(
    val ssimTarget: Double = 0.95,
    val minQuality: Int = 40,              // нижняя граница Q: защита от нечитаемого текста
    val deleteTempFolder: Boolean = true,  // удалить папку со сжатыми файлами после архивации
    val deleteOriginals: Boolean = false,  // удалить исходные фото после успешной архивации
    val compressionMethod: CompressionMethod = CompressionMethod.ANDROID,
    /** PDF: max long side in px; 0 = keep original resolution. */
    val pdfMaxSide: Int = 2048,
    /** PDF: convert to grayscale before JPEG encode. */
    val pdfGrayscale: Boolean = false,
    /** PDF: which JPEG encoder embeds into the page. */
    val pdfInnerCodec: PdfInnerCodec = PdfInnerCodec.MOZJPEG,
    /** Camera PDF: fixed JPEG quality (SSIM search is for batch processing only). */
    val pdfCaptureQuality: Int = 80,
)

data class ProcessProgress(val running: Boolean = false, val message: String = "", val current: Int = 0, val total: Int = 0)

sealed interface ProcessResult {
    data class Success(
        val zipName: String,
        val zipUri: Uri,
        val zipSize: Long,
        val files: Int,
        val originalBytes: Long,
        val deletedOriginals: Int,
        val warnings: List<String>,
        val shareUri: Uri? = null,
        val createdAt: Long = System.currentTimeMillis(),
    ) : ProcessResult

    data class Failure(val reason: String) : ProcessResult
}

class Processor(private val context: Context) {
    private val resolver get() = context.contentResolver

    suspend fun run(
        images: List<ImageItem>,
        outputTree: Uri,
        archiveTree: Uri,
        settings: ProcessSettings,
        onProgress: (String, Int, Int) -> Unit,
    ): ProcessResult = withContext(Dispatchers.Default) {
        try {
            doRun(images, outputTree, archiveTree, settings, onProgress)
        } catch (e: CancellationException) {
            throw e
        } catch (e: OutOfMemoryError) {
            ProcessResult.Failure("Не хватило памяти на обработку большого снимка. Исходные фото не тронуты.")
        } catch (e: Exception) {
            ProcessResult.Failure("Ошибка: ${e.message ?: e.javaClass.simpleName}. Исходные фото не тронуты.")
        }
    }

    private suspend fun doRun(
        images: List<ImageItem>,
        outputTree: Uri,
        archiveTree: Uri,
        st: ProcessSettings,
        onProgress: (String, Int, Int) -> Unit,
    ): ProcessResult {
        if (images.isEmpty()) return ProcessResult.Failure("Не выбрано ни одного файла")

        val outRoot = DocumentFile.fromTreeUri(context, outputTree)
        val arcRoot = DocumentFile.fromTreeUri(context, archiveTree)
        if (outRoot == null || arcRoot == null || !outRoot.canWrite() || !arcRoot.canWrite()) {
            return ProcessResult.Failure("Нет доступа на запись в выбранные папки. Выберите их заново.")
        }

        // Имя папки/архива: текущая дата; при повторном запуске в тот же день — _2, _3...
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        var n = 1
        fun nameFor(i: Int) = if (i == 1) date else "${date}_$i"
        while (outRoot.findFile(nameFor(n)) != null || arcRoot.findFile("${nameFor(n)}.zip") != null) n++
        val folderName = nameFor(n)

        val folder = outRoot.createDirectory(folderName)
            ?: return ProcessResult.Failure("Не удалось создать папку $folderName")

        // 1. Сжатие
        val written = mutableListOf<Pair<String, Long>>()
        val warnings = mutableListOf<String>()
        var originalBytes = 0L
        for ((index, img) in images.withIndex()) {
            currentCoroutineContext().ensureActive()
            onProgress("Сжатие ${index + 1}/${images.size}: ${img.name}", index, images.size)

            val encoded = compressOne(img.uri, img.name, st, warnings)
            var bytes = encoded.bytes
            val isJpegInput = img.name.lowercase().let { it.endsWith(".jpg") || it.endsWith(".jpeg") }
            val jpegOutput = st.compressionMethod in setOf(
                CompressionMethod.ANDROID, CompressionMethod.JPEGLI, CompressionMethod.MOZJPEG
            )
            if (jpegOutput && isJpegInput && bytes.size.toLong() >= img.size && img.size > 0) {
                // Пережатие не помогло — оставляем оригинальные байты
                bytes = resolver.openInputStream(img.uri)?.use { it.readBytes() } ?: bytes
                warnings += "${img.name}: уже оптимален, скопирован без изменений"
            }

            val fileName = uniqueName(folder, img.name.substringBeforeLast('.') + ".${encoded.extension}")
            val doc = folder.createFile(encoded.mimeType, fileName)
                ?: return ProcessResult.Failure("Не удалось создать файл $fileName в папке $folderName")
            val out = resolver.openOutputStream(doc.uri)
                ?: return ProcessResult.Failure("Не удалось записать $fileName")
            out.use { it.write(bytes) }
            written += (doc.name ?: fileName) to bytes.size.toLong()
            originalBytes += img.size
        }

        // 2. ZIP
        onProgress("Создание архива…", images.size, images.size)
        val zipName = "$folderName.zip"
        val zipDoc = arcRoot.createFile("application/zip", zipName)
            ?: return ProcessResult.Failure("Не удалось создать архив $zipName")
        val zipStream = resolver.openOutputStream(zipDoc.uri)
            ?: return ProcessResult.Failure("Не удалось записать архив $zipName")
        ZipOutputStream(BufferedOutputStream(zipStream)).use { zip ->
            zip.setLevel(Deflater.NO_COMPRESSION) // JPEG всё равно не сжимается
            val files = folder.listFiles().filter { it.isFile }.sortedBy { it.name }
            for (f in files) {
                currentCoroutineContext().ensureActive()
                zip.putNextEntry(ZipEntry("$folderName/${f.name}"))
                resolver.openInputStream(f.uri)?.use { it.copyTo(zip) }
                zip.closeEntry()
            }
        }

        // 3. Проверка архива через ZipFile: наличие, размер и CRC каждого файла.
        // Архив SAF-каталога временно копируется в cache, а содержимое читается потоково.
        onProgress("Проверка архива…", images.size, images.size)
        val activeContext = currentCoroutineContext()
        val verifyFile = File.createTempFile("persistor-verify-", ".zip", context.cacheDir)
        val verificationError = try {
            val zipIn = resolver.openInputStream(zipDoc.uri)
                ?: error("Не удалось открыть архив для проверки")
            zipIn.use { input ->
                verifyFile.outputStream().buffered().use { output ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        activeContext.ensureActive()
                        val count = input.read(buffer)
                        if (count < 0) break
                        if (count > 0) output.write(buffer, 0, count)
                    }
                }
            }

            val expected = written.associate { (name, size) -> "$folderName/$name" to size }
            ArchiveVerifier.verify(verifyFile, expected) { activeContext.ensureActive() }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            "ошибка чтения ZIP/CRC: ${e.message ?: e.javaClass.simpleName}"
        } finally {
            verifyFile.delete()
        }
        if (verificationError != null) {
            zipDoc.delete()
            return ProcessResult.Failure(
                "Проверка архива не прошла: $verificationError. Исходные фото не тронуты, " +
                    "сжатые файлы остались в папке $folderName."
            )
        }
        val zipSize = zipDoc.length()

        // 4. Очистка — только после успешной проверки
        if (st.deleteTempFolder) folder.delete()
        var deleted = 0
        if (st.deleteOriginals) {
            for (img in images) {
                val ok2 = DocumentFile.fromSingleUri(context, img.uri)?.delete() == true
                if (ok2) deleted++ else warnings += "Не удалось удалить ${img.name}"
            }
        }

        return ProcessResult.Success(zipName, zipDoc.uri, zipSize, written.size, originalBytes, deleted, warnings)
    }

    private data class EncodedImage(val bytes: ByteArray, val extension: String, val mimeType: String)

    /** Подбор качества SSIM для всех цветовых кодеков, включая PDF (JPEG внутри). */
    private fun compressOne(uri: Uri, name: String, st: ProcessSettings, warnings: MutableList<String>): EncodedImage {
        // Already a PDF: archive as-is (camera PDF pipeline).
        if (name.endsWith(".pdf", ignoreCase = true)) {
            val bytes = resolver.openInputStream(uri)?.use { it.readBytes() }
                ?: error("Не удалось прочитать $name")
            warnings += "$name: PDF уже готов, скопирован без перекодирования"
            return EncodedImage(bytes, "pdf", "application/pdf")
        }
        val decoded = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            ?: error("Не удалось прочитать $name")
        var bmp = decoded.applyOrientation(readOrientation(uri))
        try {
            if (st.compressionMethod.isPdf) {
                bmp = prepareForPdf(bmp, st)
            }
            var lo = st.minQuality
            var hi = 95
            var best: ByteArray? = null
            var iter = 0
            while (lo <= hi && iter < 8) {
                iter++
                val mid = (lo + hi) / 2
                val bytes = encode(bmp, mid, st)
                if (ssimOf(bmp, bytes, st.compressionMethod) >= st.ssimTarget) {
                    best = bytes
                    hi = mid - 1   // качество достаточное — пробуем сжать сильнее
                } else {
                    lo = mid + 1
                }
            }
            if (best == null) {
                warnings += "$name: цель SSIM не достигнута, использовано качество 95"
                best = encode(bmp, 95, st)
            }
            return EncodedImage(best, st.compressionMethod.extension, st.compressionMethod.mimeType)
        } finally {
            bmp.recycle()
        }
    }

    /**
     * Resize (max long side) + optional grayscale for the PDF pipeline.
     * Always returns a bitmap the caller may recycle. If transformations were applied,
     * [src] is recycled here; otherwise [src] is returned as-is.
     */
    private fun prepareForPdf(src: Bitmap, st: ProcessSettings): Bitmap {
        var current = src
        val maxSide = st.pdfMaxSide
        if (maxSide > 0) {
            val longSide = maxOf(current.width, current.height)
            if (longSide > maxSide) {
                val scale = maxSide.toFloat() / longSide
                val w = (current.width * scale).toInt().coerceAtLeast(1)
                val h = (current.height * scale).toInt().coerceAtLeast(1)
                val scaled = Bitmap.createScaledBitmap(current, w, h, true)
                if (scaled !== current) {
                    if (current !== src) current.recycle()
                    current = scaled
                }
            }
        }
        if (st.pdfGrayscale) {
            val gray = toGrayscale(current)
            if (gray !== current) {
                if (current !== src) current.recycle()
                current = gray
            }
        }
        if (current !== src) src.recycle()
        return current
    }

    private fun toGrayscale(src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(out)
        val paint = android.graphics.Paint()
        val cm = android.graphics.ColorMatrix().apply { setSaturation(0f) }
        paint.colorFilter = android.graphics.ColorMatrixColorFilter(cm)
        canvas.drawBitmap(src, 0f, 0f, paint)
        return out
    }

    private fun encodeJpeg(bmp: Bitmap, q: Int, codec: PdfInnerCodec): ByteArray = when (codec) {
        PdfInnerCodec.ANDROID -> {
            val out = ByteArrayOutputStream(512 * 1024)
            check(bmp.compress(Bitmap.CompressFormat.JPEG, q, out)) { "Android JPEG encoder failed" }
            out.toByteArray()
        }
        PdfInnerCodec.JPEGLI -> JpegliEncoder.encode(bmp, q)
        PdfInnerCodec.MOZJPEG -> NativeImageEncoder.encodeMozJpeg(bmp, q)
    }

    private fun encode(bmp: Bitmap, q: Int, st: ProcessSettings): ByteArray = when (st.compressionMethod) {
        CompressionMethod.ANDROID -> encodeJpeg(bmp, q, PdfInnerCodec.ANDROID)
        CompressionMethod.JPEGLI -> encodeJpeg(bmp, q, PdfInnerCodec.JPEGLI)
        CompressionMethod.MOZJPEG -> encodeJpeg(bmp, q, PdfInnerCodec.MOZJPEG)
        CompressionMethod.WEBP -> PlatformImageEncoder.encodeWebp(bmp, q)
        CompressionMethod.JPEG_XL -> JxlEncoder.encode(bmp, q)
        CompressionMethod.HEIF -> PlatformImageEncoder.encodeHeif(bmp, q, context.cacheDir)
        CompressionMethod.AVIF -> PlatformImageEncoder.encodeAvif(bmp, q, context.cacheDir)
        CompressionMethod.PDF_JPEG -> {
            val jpeg = encodeJpeg(bmp, q, st.pdfInnerCodec)
            // Grayscale JPEG is still 3-component from our encoders unless we force; wrap as RGB.
            PdfEncoder.wrapJpeg(jpeg, bmp.width, bmp.height)
        }
    }

    private fun ssimOf(orig: Bitmap, bytes: ByteArray, method: CompressionMethod): Double {
        val dec = when (method) {
            CompressionMethod.JPEG_XL -> JxlEncoder.decode(bytes)
            CompressionMethod.PDF_JPEG -> {
                // Decode the embedded JPEG from the PDF for SSIM (same pixels as the JPEG we wrapped).
                val jpeg = PdfEncoder.extractJpeg(bytes) ?: error("PDF does not contain an embedded JPEG for SSIM")
                BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size)
            }
            else -> BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        }
            ?: error("Android could not decode the encoded image for SSIM validation; the device may not support this codec")
        try {
            return Ssim.compute(orig, dec)
        } finally {
            dec.recycle()
        }
    }

    private fun readOrientation(uri: Uri): Int =
        resolver.openInputStream(uri)?.use {
            ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        } ?: ExifInterface.ORIENTATION_NORMAL

    /** Физически поворачиваем пиксели по EXIF, потому что в результат EXIF не копируется. */
    private fun Bitmap.applyOrientation(o: Int): Bitmap {
        val m = Matrix()
        when (o) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(-90f); m.postScale(-1f, 1f) }
            else -> return this
        }
        val rotated = Bitmap.createBitmap(this, 0, 0, width, height, m, true)
        if (rotated !== this) recycle()
        return rotated
    }

    private fun uniqueName(dir: DocumentFile, name: String): String {
        if (dir.findFile(name) == null) return name
        val base = name.substringBeforeLast('.')
        val ext = name.substringAfterLast('.', "")
        var i = 2
        while (true) {
            val c = if (ext.isEmpty()) "${base}_$i" else "${base}_$i.$ext"
            if (dir.findFile(c) == null) return c
            i++
        }
    }
}
