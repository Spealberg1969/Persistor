package com.persistor

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import androidx.exifinterface.media.ExifInterface
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import kotlin.math.roundToInt

/** Поворот пикселей по EXIF (в результат EXIF не копируется). */
fun Bitmap.applyExifOrientation(o: Int): Bitmap {
    val m = Matrix()
    when (o) {
        ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
        ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
        ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
        ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
        ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
        ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
        ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(-90f); m.postScale(-1f, 1f) }
        else -> return this
    }
    val rotated = Bitmap.createBitmap(this, 0, 0, width, height, m, true)
    if (rotated !== this) recycle()
    return rotated
}

object PhotoProcessor {

    /**
     * Converts an upright JPEG capture into a single-page PDF using [st] PDF knobs
     * (max side, grayscale, capture quality, inner codec). Used by the camera PDF mode.
     */
    fun jpegToPdf(jpegBytes: ByteArray, st: ProcessSettings): ByteArray {
        var bmp = BitmapFactory.decodeByteArray(jpegBytes, 0, jpegBytes.size)
            ?: error("Не удалось декодировать снимок для PDF")
        try {
            val maxSide = st.pdfMaxSide
            if (maxSide > 0) {
                val longSide = maxOf(bmp.width, bmp.height)
                if (longSide > maxSide) {
                    val scale = maxSide.toFloat() / longSide
                    val w = (bmp.width * scale).toInt().coerceAtLeast(1)
                    val h = (bmp.height * scale).toInt().coerceAtLeast(1)
                    val scaled = Bitmap.createScaledBitmap(bmp, w, h, true)
                    if (scaled !== bmp) {
                        bmp.recycle()
                        bmp = scaled
                    }
                }
            }
            if (st.pdfGrayscale) {
                val gray = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
                val canvas = android.graphics.Canvas(gray)
                val paint = android.graphics.Paint()
                paint.colorFilter = android.graphics.ColorMatrixColorFilter(
                    android.graphics.ColorMatrix().apply { setSaturation(0f) }
                )
                canvas.drawBitmap(bmp, 0f, 0f, paint)
                bmp.recycle()
                bmp = gray
            }
            val q = st.pdfCaptureQuality.coerceIn(40, 95)
            val jpeg = when (st.pdfInnerCodec) {
                PdfInnerCodec.ANDROID -> {
                    val out = ByteArrayOutputStream(512 * 1024)
                    check(bmp.compress(Bitmap.CompressFormat.JPEG, q, out)) { "JPEG encode failed" }
                    out.toByteArray()
                }
                PdfInnerCodec.JPEGLI -> JpegliEncoder.encode(bmp, q)
                PdfInnerCodec.MOZJPEG -> NativeImageEncoder.encodeMozJpeg(bmp, q)
            }
            return PdfEncoder.wrapJpeg(jpeg, bmp.width, bmp.height)
        } finally {
            bmp.recycle()
        }
    }

    /**
     * Поворачивает пиксели по EXIF Orientation и сохраняет JPEG без тега ориентации,
     * чтобы файл всегда отображался «прямо» в любом просмотрщике.
     */
    fun ensureUprightJpeg(bytes: ByteArray, quality: Int = 95): ByteArray {
        val orientation = ExifInterface(ByteArrayInputStream(bytes))
            .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        if (orientation == ExifInterface.ORIENTATION_NORMAL ||
            orientation == ExifInterface.ORIENTATION_UNDEFINED
        ) {
            return bytes
        }
        var bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return bytes
        bmp = bmp.applyExifOrientation(orientation)
        val out = ByteArrayOutputStream(bytes.size)
        bmp.compress(Bitmap.CompressFormat.JPEG, quality, out)
        bmp.recycle()
        return out.toByteArray()
    }

    /**
     * Поворачивает JPEG на [degrees] по часовой (0/90/180/270) и сохраняет без EXIF-ориентации.
     * Используется камерой: угол берётся из датчика устройства + SENSOR_ORIENTATION.
     */
    fun rotateJpegDegrees(bytes: ByteArray, degrees: Int, quality: Int = 95): ByteArray {
        val d = ((degrees % 360) + 360) % 360
        if (d == 0) return ensureUprightJpeg(bytes, quality)
        var bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return bytes
        // Drop any EXIF orientation first so we only apply the device-based rotation once.
        val exifOri = ExifInterface(ByteArrayInputStream(bytes))
            .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        if (exifOri != ExifInterface.ORIENTATION_NORMAL && exifOri != ExifInterface.ORIENTATION_UNDEFINED) {
            bmp = bmp.applyExifOrientation(exifOri)
        }
        val m = Matrix().apply { postRotate(d.toFloat()) }
        val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        if (rotated !== bmp) bmp.recycle()
        val out = ByteArrayOutputStream(bytes.size)
        rotated.compress(Bitmap.CompressFormat.JPEG, quality, out)
        rotated.recycle()
        return out.toByteArray()
    }

    /**
     * Свой размер снимка: кадр поворачивается как надо, обрезается по центру до нужных пропорций
     * и уменьшается до targetW×targetH (больше, чем есть в кадре, не получится, увеличения нет).
     */
    fun cropResize(bytes: ByteArray, targetW: Int, targetH: Int, quality: Int = 95): ByteArray {
        val orientation = ExifInterface(ByteArrayInputStream(bytes))
            .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        var bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: error("Не удалось прочитать снимок")
        bmp = bmp.applyExifOrientation(orientation)

        val aspect = targetW.toFloat() / targetH
        var cw = bmp.width
        var ch = (cw / aspect).roundToInt()
        if (ch > bmp.height) {
            ch = bmp.height
            cw = (ch * aspect).roundToInt()
        }
        cw = cw.coerceIn(1, bmp.width)
        ch = ch.coerceIn(1, bmp.height)
        val x = (bmp.width - cw) / 2
        val y = (bmp.height - ch) / 2
        var cur = Bitmap.createBitmap(bmp, x, y, cw, ch)
        if (cur !== bmp) bmp.recycle()

        var tw = targetW
        var th = targetH
        if (tw > cw || th > ch) {
            val k = minOf(cw.toFloat() / tw, ch.toFloat() / th)
            tw = (tw * k).roundToInt().coerceAtLeast(1)
            th = (th * k).roundToInt().coerceAtLeast(1)
        }

        // Уменьшаем ступенями вдвое, чтобы не терять качество на больших коэффициентах
        while (cur.width / 2 >= tw && cur.height / 2 >= th) {
            val n = Bitmap.createScaledBitmap(cur, cur.width / 2, cur.height / 2, true)
            if (n !== cur) cur.recycle()
            cur = n
        }
        if (cur.width != tw || cur.height != th) {
            val n = Bitmap.createScaledBitmap(cur, tw, th, true)
            if (n !== cur) cur.recycle()
            cur = n
        }
        val out = ByteArrayOutputStream(512 * 1024)
        cur.compress(Bitmap.CompressFormat.JPEG, quality, out)
        cur.recycle()
        return out.toByteArray()
    }
}
