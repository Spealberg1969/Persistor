package com.persistor

import android.graphics.Bitmap

/** Native codecs bundled with the Android app. */
internal object NativeImageEncoder {
    private val mozJpegLoadError: Throwable? = load("persistor_mozjpeg")

    private fun load(name: String): Throwable? = try {
        System.loadLibrary(name)
        null
    } catch (error: UnsatisfiedLinkError) {
        error
    } catch (error: SecurityException) {
        error
    }

    fun encodeMozJpeg(bitmap: Bitmap, quality: Int): ByteArray {
        mozJpegLoadError?.let { throw IllegalStateException("MozJPEG native library is unavailable", it) }
        return nativeEncodeMozJpeg(bitmap, quality)
    }

    private external fun nativeEncodeMozJpeg(bitmap: Bitmap, quality: Int): ByteArray
}
