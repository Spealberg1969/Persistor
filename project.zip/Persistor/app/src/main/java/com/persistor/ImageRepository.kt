package com.persistor

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class ImageItem(val uri: Uri, val name: String, val size: Long, val modified: Long) {
    val isPdf: Boolean
        get() = name.endsWith(".pdf", ignoreCase = true)
}

class ImageRepository(private val context: Context) {

    /** Images and PDFs from selected folders, newest first. */
    suspend fun list(sources: Set<Uri>): List<ImageItem> = withContext(Dispatchers.IO) {
        sources.flatMap { tree ->
            val dir = DocumentFile.fromTreeUri(context, tree) ?: return@flatMap emptyList()
            dir.listFiles()
                .filter { f ->
                    if (!f.isFile) return@filter false
                    val type = f.type.orEmpty()
                    val name = f.name.orEmpty()
                    type.startsWith("image/") ||
                        type == "application/pdf" ||
                        name.endsWith(".jpg", true) ||
                        name.endsWith(".jpeg", true) ||
                        name.endsWith(".pdf", true)
                }
                .map { ImageItem(it.uri, it.name ?: "?", it.length(), it.lastModified()) }
        }.sortedByDescending { it.modified }
    }

    fun folderName(uri: Uri): String =
        DocumentFile.fromTreeUri(context, uri)?.name ?: uri.lastPathSegment ?: "?"
}
