package com.persistor

import java.io.ByteArrayOutputStream
import java.nio.charset.StandardCharsets

/**
 * Minimal single-page PDF writer that embeds a JPEG via /Filter /DCTDecode.
 * The image is not re-encoded: PDF is a thin container around the already-compressed JPEG.
 */
internal object PdfEncoder {

    fun wrapJpeg(jpeg: ByteArray, width: Int, height: Int): ByteArray {
        require(width > 0 && height > 0) { "Invalid image size for PDF" }
        require(jpeg.isNotEmpty()) { "Empty JPEG for PDF" }

        val objects = mutableListOf<ByteArray>()
        // 1: Catalog
        objects += obj(1, "<< /Type /Catalog /Pages 2 0 R >>")
        // 2: Pages
        objects += obj(2, "<< /Type /Pages /Kids [3 0 R] /Count 1 >>")
        // 3: Page
        objects += obj(
            3,
            "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 $width $height] " +
                "/Contents 4 0 R /Resources << /XObject << /Im0 5 0 R >> >> >>",
        )
        // 4: Content stream — draw image to fill the page
        val content = "q\n$width 0 0 $height 0 0 cm\n/Im0 Do\nQ\n"
        val contentBytes = content.toByteArray(StandardCharsets.US_ASCII)
        objects += objStream(4, contentBytes)
        // 5: Image XObject with DCTDecode (JPEG passthrough)
        val imgDict =
            "<< /Type /XObject /Subtype /Image /Width $width /Height $height " +
                "/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode " +
                "/Length ${jpeg.size} >>"
        objects += objStream(5, jpeg, dictOverride = imgDict)

        val out = ByteArrayOutputStream(jpeg.size + 1024)
        out.write("%PDF-1.4\n".toByteArray(StandardCharsets.US_ASCII))
        val offsets = IntArray(objects.size + 1)
        for (i in objects.indices) {
            offsets[i + 1] = out.size()
            out.write(objects[i])
        }
        val xrefPos = out.size()
        val xref = StringBuilder()
        xref.append("xref\n0 ${objects.size + 1}\n")
        xref.append("0000000000 65535 f \n")
        for (i in 1..objects.size) {
            xref.append(String.format("%010d 00000 n \n", offsets[i]))
        }
        xref.append("trailer << /Size ${objects.size + 1} /Root 1 0 R >>\n")
        xref.append("startxref\n$xrefPos\n%%EOF\n")
        out.write(xref.toString().toByteArray(StandardCharsets.US_ASCII))
        return out.toByteArray()
    }

    /** Best-effort extract of the first DCTDecode stream (our embedded JPEG). */
    fun extractJpeg(pdf: ByteArray): ByteArray? {
        val marker = "/Filter /DCTDecode".toByteArray(StandardCharsets.US_ASCII)
        val streamMark = "stream".toByteArray(StandardCharsets.US_ASCII)
        val endMark = "endstream".toByteArray(StandardCharsets.US_ASCII)
        val idx = indexOf(pdf, marker, 0) ?: return null
        val streamStart = indexOf(pdf, streamMark, idx) ?: return null
        var dataStart = streamStart + streamMark.size
        // Skip optional \r and/or \n after "stream"
        if (dataStart < pdf.size && pdf[dataStart] == '\r'.code.toByte()) dataStart++
        if (dataStart < pdf.size && pdf[dataStart] == '\n'.code.toByte()) dataStart++
        val end = indexOf(pdf, endMark, dataStart) ?: return null
        var dataEnd = end
        // Trim trailing newline before endstream
        if (dataEnd > dataStart && pdf[dataEnd - 1] == '\n'.code.toByte()) dataEnd--
        if (dataEnd > dataStart && pdf[dataEnd - 1] == '\r'.code.toByte()) dataEnd--
        if (dataEnd <= dataStart) return null
        return pdf.copyOfRange(dataStart, dataEnd)
    }

    private fun obj(num: Int, body: String): ByteArray =
        "$num 0 obj\n$body\nendobj\n".toByteArray(StandardCharsets.US_ASCII)

    private fun objStream(num: Int, data: ByteArray, dictOverride: String? = null): ByteArray {
        val dict = dictOverride ?: "<< /Length ${data.size} >>"
        val header = "$num 0 obj\n$dict\nstream\n".toByteArray(StandardCharsets.US_ASCII)
        val footer = "\nendstream\nendobj\n".toByteArray(StandardCharsets.US_ASCII)
        val out = ByteArrayOutputStream(header.size + data.size + footer.size)
        out.write(header)
        out.write(data)
        out.write(footer)
        return out.toByteArray()
    }

    private fun indexOf(hay: ByteArray, needle: ByteArray, from: Int): Int? {
        outer@ for (i in from..(hay.size - needle.size)) {
            for (j in needle.indices) {
                if (hay[i + j] != needle[j]) continue@outer
            }
            return i
        }
        return null
    }
}
