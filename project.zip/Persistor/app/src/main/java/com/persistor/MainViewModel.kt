package com.persistor

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class UiState(
    val sources: Set<Uri> = emptySet(),
    val output: Uri? = null,
    val archive: Uri? = null,
    val cameraJpeg: Uri? = null,
    val cameraPdf: Uri? = null,
    val images: List<ImageItem> = emptyList(),
    val selected: Set<Uri> = emptySet(),
    val settings: ProcessSettings = ProcessSettings(),
    val mail: MailSettings = MailSettings(),
    val quickMode: Boolean = false,
    val progress: ProcessProgress = ProcessProgress(),
    val result: ProcessResult? = null,
    val history: List<HistoryEntry> = emptyList(),
    val theme: ThemeMode = ThemeMode.LIGHT,
)

private data class Prefs(
    val settings: ProcessSettings,
    val mail: MailSettings,
    val quick: Boolean,
    val history: List<HistoryEntry>,
    val theme: ThemeMode,
)

private data class Folders(
    val sources: Set<Uri>,
    val output: Uri?,
    val archive: Uri?,
    val cameraJpeg: Uri?,
    val cameraPdf: Uri?,
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val store = FolderStore(app)
    val repo = ImageRepository(app)

    private val images = MutableStateFlow<List<ImageItem>>(emptyList())
    private val selected = MutableStateFlow<Set<Uri>>(emptySet())
    private var autoSentFor: ProcessResult? = null

    private val folders = combine(
        store.sources, store.output, store.archive, store.cameraJpeg, store.cameraPdf,
    ) { s, o, a, cj, cp -> Folders(s, o, a, cj, cp) }
    private val items = combine(images, selected) { i, s -> i to s }
    private val prefs = combine(store.settings, store.mail, store.quickMode, store.history, store.theme) { a, b, c, d, e ->
        Prefs(a, b, c, d, e)
    }

    val state: StateFlow<UiState> = combine(
        folders, items, prefs, ProcessingState.progress, ProcessingState.result
    ) { f, im, p, pr, r ->
        UiState(
            sources = f.sources,
            output = f.output,
            archive = f.archive,
            cameraJpeg = f.cameraJpeg,
            cameraPdf = f.cameraPdf,
            images = im.first,
            selected = im.second,
            settings = p.settings,
            mail = p.mail,
            quickMode = p.quick,
            progress = pr,
            result = r,
            history = p.history,
            theme = p.theme,
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, UiState())

    init {
        viewModelScope.launch { store.sources.collect { reload(it) } }
        viewModelScope.launch { ProcessingState.result.filterNotNull().collect { reload(state.value.sources) } }
    }

    private suspend fun reload(src: Set<Uri>) {
        val list = repo.list(src)
        images.value = list
        selected.value = selected.value intersect list.map { it.uri }.toSet()
    }

    private fun persist(uri: Uri) {
        getApplication<Application>().contentResolver.takePersistableUriPermission(
            uri,
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        )
    }

    fun addSource(uri: Uri) { persist(uri); viewModelScope.launch { store.addSource(uri) } }
    fun removeSource(uri: Uri) = viewModelScope.launch { store.removeSource(uri) }
    fun setOutput(uri: Uri) { persist(uri); viewModelScope.launch { store.setOutput(uri) } }
    fun setArchive(uri: Uri) { persist(uri); viewModelScope.launch { store.setArchive(uri) } }
    fun setCameraJpeg(uri: Uri) { persist(uri); viewModelScope.launch { store.setCameraJpeg(uri) } }
    fun setCameraPdf(uri: Uri) { persist(uri); viewModelScope.launch { store.setCameraPdf(uri) } }

    fun setSsim(v: Double) = viewModelScope.launch { store.setSsim(v) }
    fun setDeleteTemp(v: Boolean) = viewModelScope.launch { store.setDeleteTemp(v) }
    fun setDeleteOriginals(v: Boolean) = viewModelScope.launch { store.setDeleteOriginals(v) }
    fun setCompressionMethod(v: CompressionMethod) = viewModelScope.launch { store.setCompressionMethod(v) }
    fun setPdfMaxSide(v: Int) = viewModelScope.launch { store.setPdfMaxSide(v) }
    fun setPdfGrayscale(v: Boolean) = viewModelScope.launch { store.setPdfGrayscale(v) }
    fun setPdfInnerCodec(v: PdfInnerCodec) = viewModelScope.launch { store.setPdfInnerCodec(v) }
    fun setPdfCaptureQuality(v: Int) = viewModelScope.launch { store.setPdfCaptureQuality(v) }
    fun setQuickMode(v: Boolean) = viewModelScope.launch { store.setQuickMode(v) }

    fun addRecipient(email: String) = viewModelScope.launch { store.addRecipient(email) }
    fun removeRecipient(email: String) = viewModelScope.launch { store.removeRecipient(email) }
    fun setRecipientSelected(email: String, on: Boolean) = viewModelScope.launch { store.setRecipientSelected(email, on) }
    fun setSubject(v: String) = viewModelScope.launch { store.setSubject(v) }
    fun setAutoMail(v: Boolean) = viewModelScope.launch { store.setAutoMail(v) }
    fun clearHistory() = viewModelScope.launch { store.clearHistory() }
    fun setTheme(v: ThemeMode) = viewModelScope.launch { store.setTheme(v) }

    fun toggle(uri: Uri) {
        selected.value = if (uri in selected.value) selected.value - uri else selected.value + uri
    }

    fun selectAll() { selected.value = images.value.map { it.uri }.toSet() }
    fun clearSelection() { selected.value = emptySet() }
    fun dismissResult() { ProcessingState.result.value = null }
    fun refreshImages() { viewModelScope.launch { reload(state.value.sources) } }

    /** Add camera JPEG folder to sources, switch to JPEG processing, select all. */
    fun useCameraJpegFolder() {
        val uri = state.value.cameraJpeg ?: return
        viewModelScope.launch {
            if (uri !in state.value.sources) store.addSource(uri)
            store.setCompressionMethod(CompressionMethod.ANDROID)
            val src = state.value.sources + uri
            reload(src)
            selectAll()
        }
    }

    /** Add camera PDF folder to sources, switch to PDF pipeline, select all. */
    fun useCameraPdfFolder() {
        val uri = state.value.cameraPdf ?: return
        viewModelScope.launch {
            if (uri !in state.value.sources) store.addSource(uri)
            store.setCompressionMethod(CompressionMethod.PDF_JPEG)
            val src = state.value.sources + uri
            reload(src)
            selectAll()
        }
    }

    /** true один раз для каждого результата: чтобы Gmail не открывался повторно при повороте экрана. */
    fun consumeAutoSend(r: ProcessResult): Boolean {
        if (autoSentFor === r) return false
        autoSentFor = r
        return true
    }

    /**
     * Открывает Gmail с последним архивом и записывает это в статистику.
     * Единая точка для кнопки в окне результата, автооткрытия и кнопки в уведомлении.
     */
    fun sendLast(context: Context): Boolean {
        val r = ProcessingState.lastSuccess ?: return false
        val uri = r.shareUri ?: return false
        val plan = ProcessingState.lastPlan
        val s = state.value
        val to = plan?.to ?: s.mail.selected.sorted()
        val subject = subjectFor(plan?.subject ?: s.mail.subject, r.zipName)
        Mailer.launch(context, uri, to, subject)
        viewModelScope.launch { store.markGmailOpened(r.createdAt, System.currentTimeMillis(), to) }
        return true
    }

    /** all = true: обработать все изображения (быстрый режим), иначе только выбранные. */
    fun process(all: Boolean = false) {
        val s = state.value
        val out = s.output ?: return
        val arc = s.archive ?: return
        if (ProcessingState.progress.value.running) return
        val chosen = if (all) images.value else images.value.filter { it.uri in selected.value }
        if (chosen.isEmpty()) return

        val plan = s.mail.selected.takeIf { it.isNotEmpty() }?.let { MailPlan(it.sorted(), s.mail.subject) }
        ProcessingState.job = ProcessJob(chosen, out, arc, s.settings, plan)
        ProcessingState.result.value = null
        ProcessingState.progress.value = ProcessProgress(true, "Запуск…", 0, chosen.size)

        val app = getApplication<Application>()
        try {
            ContextCompat.startForegroundService(app, Intent(app, ProcessingService::class.java))
        } catch (e: Exception) {
            ProcessingState.job = null
            ProcessingState.progress.value = ProcessProgress()
            ProcessingState.result.value = ProcessResult.Failure("Не удалось запустить обработку: ${e.message}")
        }
    }
}
