package com.persistor

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ArchiveNamingTest {
    @Test
    fun archiveNameIsFolderNameWithZipExtension() {
        assertEquals("12.11.2026_jpeg.zip", archiveZipName("12.11.2026_jpeg"))
        assertEquals("12.11.2026_pdf.zip", archiveZipName("12.11.2026_pdf"))
        assertEquals("12.11.2026_jpeg_pdf.zip", archiveZipName("12.11.2026_jpeg_pdf"))
    }

    @Test
    fun folderBaseNameReflectsContentTypes() {
        val today = SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date())
        assertEquals("${today}_jpeg", buildOutputFolderBaseName(hasJpeg = true, hasPdf = false))
        assertEquals("${today}_pdf", buildOutputFolderBaseName(hasJpeg = false, hasPdf = true))
        assertEquals("${today}_jpeg_pdf", buildOutputFolderBaseName(hasJpeg = true, hasPdf = true))
    }

    @Test
    fun folderBaseNameUsesDayMonthYearOrder() {
        val name = buildOutputFolderBaseName(hasJpeg = true, hasPdf = false)
        assertTrue(name.matches(Regex("""\d{2}\.\d{2}\.\d{4}_jpeg""")))
    }
}
